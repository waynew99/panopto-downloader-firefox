# iPanopto - a Panopto video download Chrome extension

This is an extension that uses the RSS links found in the html code of Panopto pages to reach and download videos on Panopto.

### Installation
Download the folder that contains the files included in the extension, and add the folder to chrome using the load unpacked option under manage extensions.

### Usage
To use it, navigate to the folder with the list of videos and click on the extension to select the desired videos. 
